<div class="sidebar">
    <div class="scrollbar-inner sidebar-wrapper">
        <div class="user">
            <div class="photo">
                <img src="<?php echo e(asset('assets/img/profile.jpg')); ?>">
            </div>
            <div class="info">
                <a class="" data-toggle="collapse" href="#collapseExample" aria-expanded="true">
                    <span>
                        Hizrian
                        <span class="user-level">Administrator</span>
                        <span class="caret"></span>
                    </span>
                </a>
                <div class="clearfix"></div>

                <div class="collapse in" id="collapseExample" aria-expanded="true" style="">
                    <ul class="nav">
                        <li>
                            <a href="#profile">
                                <span class="link-collapse">My Profile</span>
                            </a>
                        </li>
                        <li>
                            <a href="#edit">
                                <span class="link-collapse">Edit Profile</span>
                            </a>
                        </li>
                        <li>
                            <a href="#settings">
                                <span class="link-collapse">Settings</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <ul class="nav">
            <li class="nav-item <?php echo e(request()->is(['/'])  ? 'active' : ''); ?>">
                <a href="<?php echo e(route('home')); ?>">
                    <i class="la la-dashboard"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="nav-item <?php echo e(request()->is(['security','security/*']) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('security.index')); ?>">
                    <i class="la la-table"></i>
                    <p>Master Security</p>
                </a>
            </li>
            <li class="nav-item <?php echo e(request()->is(['resident','resident/*']) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('resident.index')); ?>">
                    <i class="la la-keyboard-o"></i>
                    <p>Master Resident</p>
                </a>
            </li>
            <li class="nav-item <?php echo e(request()->is(['visitor','visitor/*']) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('visitor.index')); ?>">
                    <i class="la la-th"></i>
                    <p>History Pengunjung</p>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH D:\elisoft\ocr_backend\resources\views/components/sidebar.blade.php ENDPATH**/ ?>